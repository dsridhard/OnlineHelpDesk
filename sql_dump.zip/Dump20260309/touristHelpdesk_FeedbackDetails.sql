-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: touristHelpdesk
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `FeedbackDetails`
--

DROP TABLE IF EXISTS `FeedbackDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FeedbackDetails` (
  `FeedbackNo` int NOT NULL AUTO_INCREMENT,
  `FeedbackMessage` varchar(200) DEFAULT NULL,
  `FeedbackDate` date DEFAULT (curdate()),
  `FeedbackTime` time DEFAULT (curtime()),
  `AdminID` varchar(20) DEFAULT NULL,
  `userID` varchar(20) DEFAULT NULL,
  `Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `Modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`FeedbackNo`),
  KEY `FK_Feedback_Admin` (`AdminID`),
  KEY `FK_Feedback_User` (`userID`),
  CONSTRAINT `FK_Feedback_Admin` FOREIGN KEY (`AdminID`) REFERENCES `StaffDetails` (`AdminID`),
  CONSTRAINT `FK_Feedback_User` FOREIGN KEY (`userID`) REFERENCES `TouristProfileDetails` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FeedbackDetails`
--

LOCK TABLES `FeedbackDetails` WRITE;
/*!40000 ALTER TABLE `FeedbackDetails` DISABLE KEYS */;
INSERT INTO `FeedbackDetails` VALUES (1,'The tour guide was exceptionally knowledgeable about the Giza pyramids!','2026-03-08','14:30:00','101','sri94','2026-03-08 10:46:09','2026-03-08 10:46:09'),(2,'sdsadasdsadsadsadas','2026-03-08','12:21:09',NULL,'testDesk','2026-03-08 12:21:09','2026-03-08 12:21:09'),(3,'sdsadaasdsadsadsdsadsadsadas','2026-03-08','12:24:39',NULL,'testDesk','2026-03-08 12:24:39','2026-03-08 12:24:39'),(8,'Sridhar side final test conducted done success','2026-03-08','16:59:29',NULL,'sridhard','2026-03-08 16:59:29','2026-03-08 16:59:29');
/*!40000 ALTER TABLE `FeedbackDetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-09  0:15:51
