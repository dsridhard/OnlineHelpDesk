-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: touristHelpdesk
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TourPlanDetails`
--

DROP TABLE IF EXISTS `TourPlanDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TourPlanDetails` (
  `TourPlanID` varchar(20) NOT NULL,
  `TourDate` date DEFAULT NULL,
  `TourTime` time DEFAULT NULL,
  `userID` varchar(20) DEFAULT NULL,
  `PlaceID` varchar(20) DEFAULT NULL,
  `GuideID` varchar(20) DEFAULT NULL,
  `Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `Modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`TourPlanID`),
  KEY `FK_Tour_User` (`userID`),
  KEY `FK_Tour_Place` (`PlaceID`),
  KEY `FK_Tour_Guide` (`GuideID`),
  CONSTRAINT `FK_Tour_Guide` FOREIGN KEY (`GuideID`) REFERENCES `GuideDetails` (`GuideID`),
  CONSTRAINT `FK_Tour_Place` FOREIGN KEY (`PlaceID`) REFERENCES `ExplorePlacesDetails` (`PlaceID`),
  CONSTRAINT `FK_Tour_User` FOREIGN KEY (`userID`) REFERENCES `TouristProfileDetails` (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TourPlanDetails`
--

LOCK TABLES `TourPlanDetails` WRITE;
/*!40000 ALTER TABLE `TourPlanDetails` DISABLE KEYS */;
INSERT INTO `TourPlanDetails` VALUES ('TP-35C84C5D','2026-09-08','20:46:00','testsridhar','2','G-101','2026-03-08 18:21:40','2026-03-08 18:21:40'),('TP-57651085','2026-03-09','10:00:00','testDesk','2','50','2026-03-08 16:26:20','2026-03-08 16:26:20'),('TP-68C2E32F','2026-07-07','13:08:00','sridhard','3','50','2026-03-08 16:38:49','2026-03-08 16:38:49');
/*!40000 ALTER TABLE `TourPlanDetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-09  0:15:51
