-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: touristHelpdesk
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TouristProfileDetails`
--

DROP TABLE IF EXISTS `TouristProfileDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TouristProfileDetails` (
  `userID` varchar(20) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `EmailId` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `MobileNo` bigint DEFAULT NULL,
  `LanguageKnown` varchar(200) DEFAULT NULL,
  `Password` varchar(50) NOT NULL,
  `PassportNo` varchar(50) DEFAULT NULL,
  `VisaDetails` varchar(50) DEFAULT NULL,
  `Created` datetime DEFAULT CURRENT_TIMESTAMP,
  `Modified` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userID`),
  UNIQUE KEY `EmailId` (`EmailId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TouristProfileDetails`
--

LOCK TABLES `TouristProfileDetails` WRITE;
/*!40000 ALTER TABLE `TouristProfileDetails` DISABLE KEYS */;
INSERT INTO `TouristProfileDetails` VALUES ('diksha','diksha','d',NULL,NULL,NULL,NULL,NULL,'123456',NULL,NULL,'2026-03-08 18:07:26','2026-03-08 18:07:26'),('sri94','Sridhar','d',NULL,NULL,'sridhar94@hotmail.com',NULL,NULL,'Test@123',NULL,NULL,'2026-02-28 11:37:32','2026-02-28 11:37:32'),('sridhard','sridhar','d',NULL,NULL,NULL,NULL,NULL,'Test@123',NULL,NULL,'2026-03-08 16:38:01','2026-03-08 16:38:01'),('testDesk','Test','b',NULL,NULL,'test@example.com',NULL,NULL,'123',NULL,NULL,'2026-03-08 03:32:37','2026-03-08 03:32:37'),('testsridhar','dsridhar ','d','D24 Parkview Apartment Abhay Khand 3 Indirapuram','India','dsridhar@irctc.co.in',8882822529,'Hindi','123456789','K4729156','V987654321','2026-03-08 18:12:28','2026-03-08 18:12:28');
/*!40000 ALTER TABLE `TouristProfileDetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-09  0:15:51
